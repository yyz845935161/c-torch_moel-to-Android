package com.example.use_cclib;

public class TtsModel {

    static {
        System.loadLibrary("tts_model");
    }

    public static native void init();
    public static native void loadmodel(String mel_filepath,String vocoder_filepath);
    public static native void run(String input);
    public static native void write_wavfile(String filename);
    //  public static native void reset();
//  public static native void acceptWaveform(short[] waveform);
//  public static native void setInputFinished();
//  public static native boolean getFinished();
//  public static native void startDecode();
//  public static native String getResult();
//    public static native void init();
    public static native void clear_data();


}

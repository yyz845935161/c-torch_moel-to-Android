package com.example.use_cclib;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        requestAudioPermissions();

//        String c =  To_an.cout_jni("abcds");
//        System.loadLibrary("to_an");
//        String c = To_an.cout_jni("good");

//        LoadModel.init("good");
//        String path = "/storage/emulated/0/tts/tts_vocoder_v3.pt";
//        String b = LoadModel.myprint();

        String  mel_filepath = "/storage/emulated/0/tts/tts_toMel_my_v1.pt";
        String vocoder_filepath = "/storage/emulated/0/tts/tts_vocoder_v3.pt";
        System.loadLibrary("tts_model");
        TtsModel.init();
        TtsModel.loadmodel(mel_filepath,vocoder_filepath);

        String a = "သတင်းထုတ်ပြန်ပါတယ်။";
        TtsModel.run(a);
        TtsModel.write_wavfile("/storage/emulated/0/tts/1.wav");
        TtsModel.clear_data();

        String b = "ဒါပေမဲ့လည်း ဒီလုပ်ရပ်ဟာ စစ်မှန်စည်းကမ်းပြည့်ဝတဲ့ ဒီမိုကရေစီ စနစ်ကိုအခြေခံတဲ့ ";
        TtsModel.run(b);
        TtsModel.write_wavfile("/storage/emulated/0/tts/2.wav");
        TtsModel.clear_data();



//        String d = GetTorch.init(path);
//   "/storage/emulated/0/tts/tts_vocoder_v3.pt"





    }



    private final int MY_PERMISSIONS_RECORD_AUDIO = 1;
    private void requestAudioPermissions() {

        if (
                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this,
                    new String[]{

                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE,

                    },
                    MY_PERMISSIONS_RECORD_AUDIO);
        }
    }

}
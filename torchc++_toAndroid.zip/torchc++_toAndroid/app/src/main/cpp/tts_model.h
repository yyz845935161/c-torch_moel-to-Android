//
// Created by yyz on 2022/11/22.
//

#ifndef _TTS_MODEL_H
#define _TTS_MODEL_H

#include "torch/script.h"
#include <iostream>
#include <memory>
#include <fstream> //文件输出
#include <locale>
#include <codecvt>
#include <jni.h>


class TtsMy
{
public:
    int run(std::string input);
    void write_wav(std::string filename);
    void clear_data();
    TtsMy(std::string key);
    TtsMy();
    std::string mel_filename;
    std::string vocoder_filename;
    void load_model();

private:
    std::string key;

    torch::jit::script::Module mel_module;
    torch::jit::script::Module vocoder_module;
    std::vector<uint16_t> wav_data;
    std::vector<int> to_id(std::string data);
    void write_wav();
    void cut_seq(std::string str, std::vector<std::string> &v);

    void decryption();

    typedef struct WAVE_HDR
    {
        /* RIFF Chunk Descriptor */
        uint8_t RIFF[4] = {'R', 'I', 'F', 'F'}; // RIFF Header Magic header
        uint32_t ChunkSize;                     // RIFF Chunk Size
        uint8_t WAVE[4] = {'W', 'A', 'V', 'E'}; // WAVE Header
        /* "fmt" sub-chunk */
        uint8_t fmt[4] = {'f', 'm', 't', ' '}; // FMT header
        uint32_t Subchunk1Size = 16;           // Size of the fmt chunk
        uint16_t AudioFormat = 1;              // Audio format 1=PCM,6=mulaw,7=alaw,     257=IBM
        // Mu-Law, 258=IBM A-Law, 259=ADPCM
        uint16_t NumOfChan = 1;                // Number of channels 1=Mono 2=Sterio
        uint32_t SamplesPerSec = 22050;        // Sampling Frequency in Hz
        uint32_t bytesPerSec = 22050 * 2;      // bytes per second
        uint16_t blockAlign = 2;               // 2=16-bit mono, 4=16-bit stereo
        uint16_t bitsPerSample = 16;           // Number of bits per sample
        /* "data" sub-chunk */
        uint8_t Subchunk2ID[4] = {'d', 'a', 't', 'a'}; // "data"  string
        uint32_t Subchunk2Size;                        // Sampled data length
    } wav_hdr;
};




#endif //_TTS_MODEL_H

//
// Created by yyz on 2022/11/22.
//

#include "tts_model.h"
#include "utils/log.h"


std::shared_ptr<TtsMy> tts;

TtsMy::TtsMy(std::string key)
{
    this->key = key;
    this->mel_filename = "tts_toMel_my_v1.pt";
    this->vocoder_filename = "tts_vocoder_v3.pt";
    this->load_model();

}

TtsMy::TtsMy()
{
    this->mel_filename = "tts_toMel_my_v1.pt";
    this->vocoder_filename = "tts_vocoder_v3.pt";
//    this->load_model();

}



// 写音频文件
void TtsMy::write_wav()
{
    static_assert(sizeof(wav_hdr) == 44, "");
    int fsize = this->wav_data.size();
    wav_hdr wav;
    wav.ChunkSize = fsize + sizeof(wav_hdr) - 8;
    wav.Subchunk2Size = fsize * 2;

    std::ofstream out("temp.wav", std::ios::binary);
    out.write(reinterpret_cast<const char *>(&wav), sizeof(wav));

    for (int i = 0; i < (int)this->wav_data.size(); ++i)
    {
        out.write(reinterpret_cast<char *>(&(this->wav_data[i])), sizeof(this->wav_data[i]));
    }

    return;
}

void TtsMy::write_wav(std::string filename)
{
    static_assert(sizeof(wav_hdr) == 44, "");
    int fsize = this->wav_data.size();
    wav_hdr wav;
    wav.ChunkSize = fsize + sizeof(wav_hdr) - 8;
    wav.Subchunk2Size = fsize * 2;

    std::ofstream out(filename, std::ios::binary);
    out.write(reinterpret_cast<const char *>(&wav), sizeof(wav));

    for (int i = 0; i < (int)this->wav_data.size(); ++i)
    {
        out.write(reinterpret_cast<char *>(&(this->wav_data[i])), sizeof(this->wav_data[i]));
    }

    return;
}

std::vector<int> TtsMy::to_id(std::string data)
{

}

void TtsMy::cut_seq(std::string str, std::vector<std::string> &v)
{
    std::string str_data = str;
    std::string temp;
    // 去除首位空格
    if (!str_data.empty())
    {
        str_data.erase(0, str_data.find_first_not_of(" "));
        str_data.erase(str_data.find_last_not_of(" ") + 1);
    }

    // 如果没有空格
    if ((int)(str_data.find(" ")) == -1)
    {
        v.push_back(str_data);
        return;
    }

    int i = 0;
    while (!str_data.empty())
    {
        int index = str_data.find(" ");
        if (index == -1)
            break;
        temp += str_data.substr(0, index) + " ";
        str_data.erase(0, index + 1);
        if (++i == 3)
        {
            v.push_back(temp);
            temp.clear();
            i = 0;
        }
    }
    v.push_back(temp + str_data);
    return;
}

void TtsMy::load_model()
{
//    decryption();

    //---加载模型
    std::string mel_path = this->mel_filename;
    std::string vocoder_path = this->vocoder_filename;

    try
    {
        this->mel_module = torch::jit::load(mel_path);
        this->vocoder_module = torch::jit::load(vocoder_path);
        LOG(INFO) << "load model ok\n";
    }
    catch (const c10::Error &e)
    {
        LOG(INFO)  << "error loading the module maybe 1:the model path is not correct  or 2:the key incorrect\n";
        // return;
    }
//    std::fstream out_file;
//    out_file.open("./.~", std::ios::binary | std::ios::out);
//    out_file << ' ';
//    remove("./.~");

}

void TtsMy::decryption()
{
    std::fstream in_file;
    std::fstream out_file;
    in_file.open(this->mel_filename, std::ios::binary | std::ios::in);
    in_file.unsetf(std::ios::skipws); // 这样就不会跳过空字节
    out_file.open("./.~", std::ios::binary | std::ios::out);

    std::string key = this->key;
    char c;
    int i = 0;
    while (in_file >> c)
    {
        c = c - key.at(i % key.size()) - i % 5;
        out_file << c;
        i++;
    }
}

void TtsMy::clear_data()
{
    this->wav_data.clear();
}

int TtsMy::run(std::string input)
{

    // 存放句子的容器
    std::vector<std::string> seq_vector;
    // 存放最终结果的容器
    std::vector<uint16_t> v_int;

    //---分句
    this->cut_seq(input, seq_vector);

    for (int i = 0; i < (int)seq_vector.size(); i++)
    {

        // 转id
        std::vector<int> model_input = to_id(seq_vector[i] + "။");
        auto input_tensor = torch::tensor(model_input);
        // std::cout<<input_tensor<<std::endl;
        input_tensor = input_tensor.unsqueeze(0);

        // tomel
        std::vector<torch::jit::IValue> input_id;
        input_id.push_back(input_tensor);
        auto mel = mel_module.forward(input_id);
        // std::cout<<mel<<std::endl;

        // 声码器
        std::vector<torch::jit::IValue> input_mel;
        input_mel.push_back(mel);
        auto wav = vocoder_module.forward(input_mel).toTensor();
        // std::cout<<wav<<std::endl;

        // 把数据转为vector
        std::vector<float> v(wav.data_ptr<float>(), wav.data_ptr<float>() + wav.numel());
        int out_size = wav.sizes()[0];
        for (int i = 0; i < out_size; i++)
        {
            this->wav_data.push_back(v[i] * 32768.0);
            // v_int.push_back(v[i] * 32768.0);
        }
    }

//    this->write_wav();
    std::cout << "successful" << std::endl;
    return 1;
}


void  init(JNIEnv* env, jobject) {

//    const char* key = env->GetStringUTFChars(jKey, nullptr);
//    std::string modelkey = std::string(key);
    tts = std::make_shared<TtsMy>();
    LOG(INFO) << "init  ok";
}

void loadmodel(JNIEnv* env, jobject,jstring mel_filename,jstring vocoder_filename)
{
    const char* pMelModelDir = env->GetStringUTFChars(mel_filename, nullptr);
    std::string modelPath = std::string(pMelModelDir);

    const char* pVocModelDir = env->GetStringUTFChars(vocoder_filename, nullptr);
    std::string vocoderPath = std::string(pVocModelDir);

    tts->mel_filename = modelPath;
    tts->vocoder_filename = vocoderPath;
    tts->load_model();

}

void run(JNIEnv* env, jobject,jstring input) {
    const char* pinput = env->GetStringUTFChars(input, nullptr);
    std::string cinput = std::string(pinput);
    LOG(INFO) << "input  is :" << cinput << "  waiting...";
    tts->run(cinput);
    LOG(INFO) << "synthetic  ok " << cinput ;
}

void write_wavfile(JNIEnv* env, jobject,jstring filename) {
    const char* pfilename = env->GetStringUTFChars(filename, nullptr);
    std::string cfilename = std::string(pfilename);
    tts->write_wav(cfilename);
    LOG(INFO) << "write  ok  path is " << cfilename ;
}

void clear_data(JNIEnv* env, jobject) {

    tts->clear_data();
    LOG(INFO) << "clear data  ok \n";
}


JNIEXPORT jint JNI_OnLoad(JavaVM *vm, void *) {
JNIEnv *env;
if (vm->GetEnv(reinterpret_cast<void **>(&env), JNI_VERSION_1_6) != JNI_OK) {
return JNI_ERR;
}

jclass c = env->FindClass("com/example/use_cclib/TtsModel");
if (c == nullptr) {
return JNI_ERR;
}

static const JNINativeMethod methods[] = {
        {"init", "()V", reinterpret_cast<void*>(init)},
        {"loadmodel", "(Ljava/lang/String;Ljava/lang/String;)V", reinterpret_cast<void *>(loadmodel)},
        {"run", "(Ljava/lang/String;)V",reinterpret_cast<void *>(run)},
        {"write_wavfile", "(Ljava/lang/String;)V",reinterpret_cast<void *>(write_wavfile)},
        {"clear_data", "()V", reinterpret_cast<void *>(clear_data)},

};
int rc = env->RegisterNatives(c, methods,
                              sizeof(methods) / sizeof(JNINativeMethod));

if (rc != JNI_OK) {
return rc;
}

return JNI_VERSION_1_6;
}






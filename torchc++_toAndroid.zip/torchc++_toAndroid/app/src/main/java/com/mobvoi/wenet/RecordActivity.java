package com.mobvoi.wenet;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.os.Process;
import android.widget.Toast;

import com.niutrans.translator.Translator;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class RecordActivity extends AppCompatActivity {


    private static final String LOG_TAG = "WENET";
    private static final int SAMPLE_RATE = 16000;  // The sampling rate
    private static final int MAX_QUEUE_SIZE = 2500;  // 100 seconds audio, 1 / 0.04 * 100

    private boolean startRecord = false;
    private AudioRecord record = null;
    private int miniBufferSize = 0;  // 1280 bytes 648 byte 40ms, 0.04s
    private final BlockingQueue<short[]> bufferQueue = new ArrayBlockingQueue<>(MAX_QUEUE_SIZE);
    private Button mBtnAsr;
    private TextView mTvAsr;
    private Button mBtnMt;
    private TextView mTvMt;

    private static final List<String> resource = Arrays.asList(
            "final.zip", "units.txt", "ctc.ort", "decoder.ort", "encoder.ort"
    );

    public static void assetsInit(Context context) throws IOException {
        AssetManager assetMgr = context.getAssets();
        // Unzip all files in resource from assets to context.
        // Note: Uninstall the APP will remove the resource files in the context.
        for (String file : assetMgr.list("")) {
            if (resource.contains(file)) {
                File dst = new File(context.getFilesDir(), file);
                if (!dst.exists() || dst.length() == 0) {
                    Log.i(LOG_TAG, "Unzipping " + file + " to " + dst.getAbsolutePath());
                    InputStream is = assetMgr.open(file);
                    OutputStream os = new FileOutputStream(dst);
                    byte[] buffer = new byte[4 * 1024];
                    int read;
                    while ((read = is.read(buffer)) != -1) {
                        os.write(buffer, 0, read);
                    }
                    os.flush();
                }
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record);

        requestAudioPermissions(); // 初始化了recorder


        // 小牛初始化
        File f = Environment.getExternalStorageDirectory();  // 获得设备的根目录路径
        final Translator handler = new Translator();
        final String path = "/storage/emulated/0/";
        boolean init_result2 = handler.load("zh", "vi",path, getApplicationContext());
        if(!init_result2){
            Toast.makeText(this, "该设备未授权或没有对应的语言模型", Toast.LENGTH_SHORT).show();
        }



        try {
            assetsInit(this); // 拷贝
        } catch (IOException e) {
            Log.e(LOG_TAG, "Error process asset files to file path");
        }

        Recognize.init(getFilesDir().getPath()); //wenet初始化

        mBtnAsr = findViewById(R.id.btn_asr);
        mTvAsr = findViewById(R.id.tv_asr);


        int minBufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE_INHZ, CHANNEL_CONFIG, AUDIO_FORMAT);
        audioRecord = new AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE_INHZ, CHANNEL_CONFIG, AUDIO_FORMAT, minBufferSize);
        mBtnAsr.setOnClickListener(view -> {
            if (!startRecord) {
                startRecord = true;
                Recognize.reset();
                startRecordThread();
                startAsrThread();
                Recognize.startDecode();
                mBtnAsr.setText("Stop Record");
            } else {
                startRecord = false;
                Recognize.setInputFinished();
                mBtnAsr.setText("Start Record");
            }
            mBtnAsr.setEnabled(false);
        });

        Context context = this;
        mBtnMt = findViewById(R.id.btn_mt);
        mBtnMt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e("TAG", "onClick: btnmt---------" );
                String output = handler.translate("你好");
                Toast.makeText(context, output, Toast.LENGTH_SHORT).show();
            }
        });




    }
    private final int MY_PERMISSIONS_RECORD_AUDIO = 1;
    private void requestAudioPermissions() {

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)
                    != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this,
                    new String[]{
                            Manifest.permission.RECORD_AUDIO,
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE,
                            Manifest.permission.READ_PHONE_STATE,
                    },
                    MY_PERMISSIONS_RECORD_AUDIO);
        } else {
            initRecorder();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions, int[] grantResults) {
        if (requestCode == MY_PERMISSIONS_RECORD_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.i(LOG_TAG, "record permission is granted");
                initRecorder();
            } else {
                Toast.makeText(this, "Permissions denied to record audio", Toast.LENGTH_LONG).show();
                mBtnAsr.setEnabled(false);
            }
        }
    }


    /**
     * ------录音---------------
     */
    private AudioRecord audioRecord;
    public static final int SAMPLE_RATE_INHZ = 16000;
    public static final int CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO;
    public static final int AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT;
    private Thread recordingAudioThread;
    private boolean isRecording = false;//mark if is recording
    int minBufferSize;

    private void initRecorder() {
        Log.e("TAG", "initRecorder: " );
        // buffer size in bytes 1280
        miniBufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT);
        if (miniBufferSize == AudioRecord.ERROR || miniBufferSize == AudioRecord.ERROR_BAD_VALUE) {
            Log.e(LOG_TAG, "Audio buffer can't initialize!");
            return;
        }
        record = new AudioRecord(MediaRecorder.AudioSource.DEFAULT,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                miniBufferSize);
        if (record.getState() != AudioRecord.STATE_INITIALIZED) {
            Log.e(LOG_TAG, "Audio Record can't initialize!");
            return;
        }
        Log.i(LOG_TAG, "Record init okay");
    }

    private void startRecordThread() {
        new Thread(() -> {
//            VoiceRectView voiceView = findViewById(R.id.voiceRectView);
            record.startRecording();
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);
            while (startRecord) {
                short[] buffer = new short[miniBufferSize / 2];
                int read = record.read(buffer, 0, buffer.length);
//                voiceView.add(calculateDb(buffer));
                try {
                    if (AudioRecord.ERROR_INVALID_OPERATION != read) {
                        bufferQueue.put(buffer);
                    }
                } catch (InterruptedException e) {
                    Log.e(LOG_TAG, e.getMessage());
                }
                if (!mBtnAsr.isEnabled() && startRecord) {
                    runOnUiThread(() -> mBtnAsr.setEnabled(true));
                }
            }
            record.stop();
//            voiceView.zero();
        }).start();
    }

    private double calculateDb(short[] buffer) {
        double energy = 0.0;
        for (short value : buffer) {
            energy += value * value;
        }
        energy /= buffer.length;
        energy = (10 * Math.log10(1 + energy)) / 100;
        energy = Math.min(energy, 1.0);
        return energy;
    }


   

    private void startAsrThread() {
        new Thread(() -> {
            // Send all data
            while (startRecord || bufferQueue.size() > 0) {
                try {
                    short[] data = bufferQueue.take();
                    // 1. add data to C++ interface
                    Recognize.acceptWaveform(data);
                    // 2. get partial result
                    runOnUiThread(() -> {

                        mTvAsr.setText(Recognize.getResult());
                    });
                } catch (InterruptedException e) {
                    Log.e("LOG_TAG", e.getMessage());
                }
            }

            // Wait for final result
            while (true) {
                // get result
                if (!Recognize.getFinished()) {
                    runOnUiThread(() -> {
                        mTvAsr.setText(Recognize.getResult());
                    });
                } else {
                    runOnUiThread(() -> {
                        mBtnAsr.setEnabled(true);
                    });
                    break;
                }
            }
        }).start();
    }
}


